import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://tuos-test.simpacc.ca/')

WebUI.setText(findTestObject('Object Repository/Est1/Page_Login - Codx.Auth/input_Login_Username'), 'simpaccone')

WebUI.setEncryptedText(findTestObject('Object Repository/Est1/Page_Login - Codx.Auth/input_Login_Password'), '/66HFEO0NguWtf4vZpQeQQ==')

WebUI.click(findTestObject('Object Repository/Est1/Page_Login - Codx.Auth/button_Login'))

WebUI.click(findTestObject('Object Repository/Est1/Page_Tuos/h1_Revenue and Collections'))

WebUI.click(findTestObject('Object Repository/Est1/Page_Tuos/a_Estimates and Quotes'))

WebUI.click(findTestObject('Object Repository/Est1/Page_Tuos/path'))

WebUI.selectOptionByValue(findTestObject('Object Repository/Est1/Page_Tuos/select_RyanBushZIRKELS SOLUTIONS INCBushSte_dc4787'), 
    '100', true)

WebUI.selectOptionByValue(findTestObject('Object Repository/Est1/Page_Tuos/select_CarSonyAlcoholSamsungChicken'), '28', 
    true)

WebUI.doubleClick(findTestObject('Object Repository/Est1/Page_Tuos/input_SubTotal_block w-full bg-white text-x_ec7ca8'))

WebUI.setText(findTestObject('Object Repository/Est1/Page_Tuos/input_SubTotal_block w-full bg-white text-x_ec7ca8_1'), '5')

WebUI.click(findTestObject('Object Repository/Est1/Page_Tuos/div_Subtotal25.00'))

WebUI.click(findTestObject('Object Repository/Est1/Page_Tuos/button_Save'))

WebUI.closeBrowser()

WebUI.closeBrowser()

WebUI.navigateToUrl('https://tuos-test.simpacc.ca/#/revenue-and-collections/estimates-and-quotes')

