<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Revenue and Collections</name>
   <tag></tag>
   <elementGuidId>a1441fe5-065d-4f6e-9cdd-03ab071c416c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[3]/div/div/div/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Revenue and Collections&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>0a276271-6cf8-4bb5-b585-40ac1b513e01</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex items-center</value>
      <webElementGuid>1ecac9ff-f3af-4c7d-9f13-7f0460e069ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Revenue and Collections</value>
      <webElementGuid>0a61a1ad-b466-411b-bc03-e71a82977aed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;lg:block md:hidden hidden lg:h-full lg:w-full&quot;]/div[@class=&quot;grid h-full gap-0 grid-cols-6&quot;]/div[@class=&quot;col-span-1 h-full border-green-500 bg-white  space-y-2  w-full&quot;]/div[@class=&quot;flex-1 px-1.5 mb-[29px]&quot;]/div[@class=&quot;w-full&quot;]/div[@class=&quot;hover:shadow-md text-[#2B461B] fill-[#27401A] pr-4 pl-8 py-0.5 hover:bg-green-50 w-full font-md text-[14px] space-y-3 rounded-xl&quot;]/div[@class=&quot;flex justify-between items-center space-x-4&quot;]/div[@class=&quot;flex space-x-4 items-center h-[48px]&quot;]/h1[@class=&quot;flex items-center&quot;]</value>
      <webElementGuid>e1c321f0-6453-4900-85df-e606569fa2f3</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[3]/div/div/div/div/h1</value>
      <webElementGuid>75373219-5b4c-44af-81be-a8b8bdc78367</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::h1[1]</value>
      <webElementGuid>063ff20e-c594-495a-bdbc-b6064aa57040</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Inventory'])[1]/preceding::h1[1]</value>
      <webElementGuid>90f588db-bbea-4ff2-b57c-52c2b8c1168b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Purchase and Payments'])[1]/preceding::h1[2]</value>
      <webElementGuid>3d6a8b66-7d3e-4de0-b4fc-eeddb3d3501b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Revenue and Collections']/parent::*</value>
      <webElementGuid>ea2d36fd-96aa-4b87-96a5-b461181da87f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/h1</value>
      <webElementGuid>6b29ba35-4c0a-434b-a5eb-64f0c281803c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Revenue and Collections' or . = 'Revenue and Collections')]</value>
      <webElementGuid>f3d42cc6-b5e3-43b6-9f79-b7f9ad282d70</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
