<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Estimates and Quotes</name>
   <tag></tag>
   <elementGuidId>973f6480-ad07-4725-8db4-bd0e00da0183</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[3]/div[2]/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Estimates and Quotes&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5d1e212c-31a2-4492-af4b-27260eaaeb40</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex py-2 w-full text-xs pr-4 pl-8 text-primary-500 hover:text-white space-x-2 rounded-lg hover:bg-primary-500</value>
      <webElementGuid>a587db68-d2e5-4b26-bec9-f3eed1c1571f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#/revenue-and-collections/estimates-and-quotes</value>
      <webElementGuid>591dd155-3a31-42df-9a4a-345b9054d1d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Estimates and Quotes</value>
      <webElementGuid>261a8ae8-3812-4038-a1e9-43c192a9f5ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;lg:block md:hidden hidden lg:h-full lg:w-full&quot;]/div[@class=&quot;grid h-full gap-0 grid-cols-6&quot;]/div[@class=&quot;col-span-1 h-full border-green-500 bg-white  space-y-2  w-full&quot;]/div[@class=&quot;flex-1 px-1.5 mb-[29px]&quot;]/div[@class=&quot;space-y-1.5 py-3&quot;]/div[@class=&quot;px-5&quot;]/a[@class=&quot;flex py-2 w-full text-xs pr-4 pl-8 text-primary-500 hover:text-white space-x-2 rounded-lg hover:bg-primary-500&quot;]</value>
      <webElementGuid>8e489315-0e00-4661-9cf8-8c9130c949de</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[3]/div[2]/div/a</value>
      <webElementGuid>441f969d-3d3e-4be5-918a-e0406b9d8944</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Estimates and Quotes')]</value>
      <webElementGuid>09b4de5a-f205-4254-997f-f4f1c670ec6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revenue and Collections'])[1]/following::a[1]</value>
      <webElementGuid>2798107c-7e0c-40ce-a4a4-1a15418b9f4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::a[1]</value>
      <webElementGuid>ab7edb68-838c-451a-94e2-40b707637baa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recurring Invoice'])[1]/preceding::a[1]</value>
      <webElementGuid>d30cc21c-a9a3-4259-bbc9-50a5ae1db30c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Invoice'])[1]/preceding::a[2]</value>
      <webElementGuid>dc2589ef-51da-4e52-939b-aa724fe0c3e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Estimates and Quotes']/parent::*</value>
      <webElementGuid>caab730a-03a4-4240-9e89-081be520733a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#/revenue-and-collections/estimates-and-quotes')]</value>
      <webElementGuid>9c3fed46-f6b3-490f-bd4c-0c6137aeead5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a</value>
      <webElementGuid>8aebd78d-667c-4a88-9e00-55f3d571865c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#/revenue-and-collections/estimates-and-quotes' and (text() = 'Estimates and Quotes' or . = 'Estimates and Quotes')]</value>
      <webElementGuid>c4527182-cc89-4ca9-8e62-d6930bdb1be0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
