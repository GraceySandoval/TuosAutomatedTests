<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Estimates and Quotes</name>
   <tag></tag>
   <elementGuidId>00e54cec-c08c-4373-8216-9c50575b7761</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[3]/div[2]/div/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Estimates and Quotes&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9caf933e-a83d-4c8e-903c-32260924b564</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex py-2 w-full text-xs pr-4 pl-8 text-primary-500 hover:text-white space-x-2 rounded-lg hover:bg-primary-500</value>
      <webElementGuid>48ba1179-8a35-45f2-b47e-1470f5607667</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#/revenue-and-collections/estimates-and-quotes</value>
      <webElementGuid>92284ec8-a61a-4dec-a379-a7d04c0be758</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Estimates and Quotes</value>
      <webElementGuid>f76c7935-4f0e-4517-94e4-8a7a1c35f10e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;lg:block md:hidden hidden lg:h-full lg:w-full&quot;]/div[@class=&quot;grid h-full gap-0 grid-cols-6&quot;]/div[@class=&quot;col-span-1 h-full border-green-500 bg-white  space-y-2  w-full&quot;]/div[@class=&quot;flex-1 px-1.5 mb-[29px]&quot;]/div[@class=&quot;space-y-1.5 py-3&quot;]/div[@class=&quot;px-5&quot;]/a[@class=&quot;flex py-2 w-full text-xs pr-4 pl-8 text-primary-500 hover:text-white space-x-2 rounded-lg hover:bg-primary-500&quot;]</value>
      <webElementGuid>022ff468-f416-4a1e-9a54-4f3eb6083e45</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[3]/div[2]/div/a</value>
      <webElementGuid>7824bd6b-8b90-4893-b30b-1c368832f649</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Estimates and Quotes')]</value>
      <webElementGuid>0da4f65f-cf3e-4804-a4e7-dfe9fc601111</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Revenue and Collections'])[1]/following::a[1]</value>
      <webElementGuid>3b881778-a2c8-4722-9098-39a385957db1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::a[1]</value>
      <webElementGuid>add48c73-090c-4cb0-bb82-155eef856e19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Recurring Invoice'])[1]/preceding::a[1]</value>
      <webElementGuid>0cd42fea-93b2-46e4-96b1-a51eef29a28a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Invoice'])[1]/preceding::a[2]</value>
      <webElementGuid>ecf22b8e-c4e7-43be-96f5-566ba8610339</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Estimates and Quotes']/parent::*</value>
      <webElementGuid>e5402941-37c1-4f4e-b790-58a277a72732</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#/revenue-and-collections/estimates-and-quotes')]</value>
      <webElementGuid>50aa1755-3060-4b3c-9d92-ec0de021e9a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/a</value>
      <webElementGuid>4fd2d7eb-f9f0-4e19-9e2c-3012aed981a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#/revenue-and-collections/estimates-and-quotes' and (text() = 'Estimates and Quotes' or . = 'Estimates and Quotes')]</value>
      <webElementGuid>143e1cbd-c414-4bb4-b3f0-f06618f8776d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
