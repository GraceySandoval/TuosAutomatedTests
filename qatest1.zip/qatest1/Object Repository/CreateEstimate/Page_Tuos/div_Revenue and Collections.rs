<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Revenue and Collections</name>
   <tag></tag>
   <elementGuidId>c5dcada7-58e1-4995-ab61-e63b3ff9d139</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div/div[3]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div >> internal:has-text=/^Revenue and Collections$/ >> nth=2</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4cf8375d-0050-4e4e-bf8a-f3dcd6e0e8c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>hover:shadow-md text-[#2B461B] fill-[#27401A] pr-4 pl-8 py-0.5 hover:bg-green-50 w-full font-md text-[14px] space-y-3 rounded-xl</value>
      <webElementGuid>7e3e61b4-c6c6-4028-bfb2-1077b224b84c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Revenue and Collections</value>
      <webElementGuid>a619d6ff-42ad-4a60-8392-990a17d54777</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;lg:block md:hidden hidden lg:h-full lg:w-full&quot;]/div[@class=&quot;grid h-full gap-0 grid-cols-6&quot;]/div[@class=&quot;col-span-1 h-full border-green-500 bg-white  space-y-2  w-full&quot;]/div[@class=&quot;flex-1 px-1.5 mb-[29px]&quot;]/div[@class=&quot;w-full&quot;]/div[@class=&quot;hover:shadow-md text-[#2B461B] fill-[#27401A] pr-4 pl-8 py-0.5 hover:bg-green-50 w-full font-md text-[14px] space-y-3 rounded-xl&quot;]</value>
      <webElementGuid>47b13e09-ba2e-44eb-b0aa-e2b073707e48</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div/div[3]/div/div</value>
      <webElementGuid>865a7080-d308-4a18-a331-b7c4d74b8820</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dashboard'])[1]/following::div[3]</value>
      <webElementGuid>51003f2f-cfca-4f90-a1fc-d0ae62a2809c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Inventory'])[1]/preceding::div[4]</value>
      <webElementGuid>643274fe-5bab-4ad3-8e44-c6044dd87880</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div</value>
      <webElementGuid>91a9f13c-5a9e-4dfe-ba45-5d3b8c300275</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Revenue and Collections' or . = 'Revenue and Collections')]</value>
      <webElementGuid>3f00350a-f789-49e1-9306-00b1f07ebefc</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
