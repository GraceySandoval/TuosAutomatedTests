<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Item NameDescriptionQuantityPriceTaxSub_ddb8ba</name>
   <tag></tag>
   <elementGuidId>2d8a982e-c54c-44e4-b2be-6fc520d6b966</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/form/div/div/div[2]/div/div/div[2]/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.inline-block >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>31b3fc94-0649-4cca-8873-03b9c7316bd7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>inline-block min-w-full py-2 align-middle md:px-6 lg:px-8 px-0</value>
      <webElementGuid>d8687190-e1d4-4059-9e39-2c3d58c0af17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Item NameDescriptionQuantityPriceTaxSubTotalCarSonyAlcoholSamsungChickenGST20GGST20GCarSonyAlcoholSamsungChickenGST20GAdd ItemSubtotal:$55.00DiscountGST (16%)$0.80Total Tax:$0.80Total:$50.80</value>
      <webElementGuid>409f96e3-c6d8-4c72-ad54-f5aa6fc351e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;lg:block md:hidden hidden lg:h-full lg:w-full&quot;]/div[@class=&quot;grid h-full gap-0 grid-cols-6&quot;]/div[@class=&quot;h-full col-span-5&quot;]/div[@class=&quot;mx-4&quot;]/div[@class=&quot;mx-auto max-w-full&quot;]/div[@class=&quot;p-4 space-y-4&quot;]/div[2]/div[@class=&quot;p-4 bg-white rounded-b-xl rounded-tr-xl&quot;]/div[@class=&quot;px-1&quot;]/div[@class=&quot;mx-auto w-full&quot;]/div[@class=&quot;overflow-visible bg-white sm:rounded-lg&quot;]/form[1]/div[@class=&quot;lg:px-6 md:px-4 px-2.5 space-y-6 pb-4&quot;]/div[@class=&quot;flex flex-col space-x-0 space-y-4 lg:flex-row lg:space-x-4 lg:space-y-0 lg:justify-between&quot;]/div[@class=&quot;flex flex-col w-full space-y-4&quot;]/div[@class=&quot;py-4&quot;]/div[@class=&quot;max-w-5x1 mx-auto&quot;]/div[@class=&quot;overflow-x-auto -my-2 lg:-mx-8 md:-mx-0 -mx-0&quot;]/div[@class=&quot;inline-block min-w-full py-2 align-middle md:px-6 lg:px-8 px-0&quot;]</value>
      <webElementGuid>e3c8d8bf-9828-439b-9994-6e7a1687c6d0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div/div/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div/form/div/div/div[2]/div/div/div[2]/div</value>
      <webElementGuid>461c3917-4c67-44a5-b03b-346c466f9c33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notes'])[1]/following::div[7]</value>
      <webElementGuid>309f9c3a-48f4-4b5e-8e7e-86246d591e41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Shipping Address'])[1]/following::div[8]</value>
      <webElementGuid>8ef7f436-231e-415c-a58d-926498951f19</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div/div/div[2]/div/div/div[2]/div</value>
      <webElementGuid>998c4584-ba57-46e1-bd75-8cef2a621a26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Item NameDescriptionQuantityPriceTaxSubTotalCarSonyAlcoholSamsungChickenGST20GGST20GCarSonyAlcoholSamsungChickenGST20GAdd ItemSubtotal:$55.00DiscountGST (16%)$0.80Total Tax:$0.80Total:$50.80' or . = 'Item NameDescriptionQuantityPriceTaxSubTotalCarSonyAlcoholSamsungChickenGST20GGST20GCarSonyAlcoholSamsungChickenGST20GAdd ItemSubtotal:$55.00DiscountGST (16%)$0.80Total Tax:$0.80Total:$50.80')]</value>
      <webElementGuid>512776a8-d5de-4c9f-9abf-da04e89f5ce0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
